
package Server;


/**
*  This is a crappy class that is NOT even USED at the current moment.
*  When we get around to implementing smart bombs and such, this is what
*  we'll use.
*/
/* NOT USED */
public class PStatus {
        public double speed, dir;
        public double newspeed, newdir;
        public double acceleration;
        public double x0, y0;
        public double x1, y1;

/**
 * This method was created by a SmartGuide.
 */
public PStatus ( ) {
  	x0 = 0;
  	y0 = 0;
  	x1 = 0;
  	y1 = 0;
        speed = (double) 5.0;
	dir = 0;
}
}
